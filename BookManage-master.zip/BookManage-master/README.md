# BookManage
图书管理系统，适合初入SSM做为练习项目
MD5+Salt加密
tomcat版本：9.0
数据库：MySQL
book.sql是数据库表
Maven项目

