import org.junit.Test;

public class test02 {
    @Test
    public  void test1(){
        String a="boss";
        System.out.println(a);
    }
}
