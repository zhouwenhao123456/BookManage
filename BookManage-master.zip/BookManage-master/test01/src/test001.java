import org.junit.*;

/*
*  1.@Test注解(类名不能为Test)
*  2.书写方法
*  返回类型为void，没有参数
*  3.注意
*     1.没有@Test注解则代码运行不了
*
*/
public class test001 {
    @Test
    public  void test1(){
        String a="boss";
        System.out.println(a);
    }
    //@Before:每个测试方法之前运行，初始化方法(如构建sqlsession对象)不能单独运行
    @Before
    public void testbefore(){
        System.out.println("每个测试方法之前都会执行的代码");
    }
    //@After:每一个测试方法之后运行，释放资源(关闭连接)
    @After
    public void testAfter(){
        System.out.println("每个测试方法之后都会执行的代码");
    }
    //@Ignore:忽略的测试方法，加上之后，暂时不运行此段代码
    @Ignore
    public  void testIgnore(){
        System.out.println("忽略的代码");
    }
    //@BeforeClass 针对所有的测试，只执行一次，且必须是static void
    @BeforeClass
    public static void testBeforeClass(){
        System.out.println("所有的方法执行之前一定会只执行一次");
    }
    //@AfterClass 所有方法执行之后都会执行的代码，且只会执行一次，必须是static void
    @AfterClass
    public static void testAfterClass(){
        System.out.println("所有的方法执行之后一定会只执行一次");
    }

}
