package com.gx.domain;

import lombok.Data;
//这里我们使用了lombook插件，一个@Data注解就可以搞定
@Data
public class User {
    private int id;
    private String username;
    private String password;
    private int grade;//角色
}
